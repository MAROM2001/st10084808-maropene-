﻿using Microsoft.AspNetCore.Mvc;

namespace checkers.Properties
{
    public class shopController : Controller
    {
        public IActionResult ShopApp()
        {
            return View();
        }
    }
}
