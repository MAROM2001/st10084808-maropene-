﻿using Microsoft.AspNetCore.Mvc;

namespace checkers.Properties
{
    public class shop2Controller : Controller
    {
        public IActionResult shop2()
        {
            return View();
        }
    }
}
